﻿"use strict";

function hello() {
  alert("Hello All");
}function numberCombiner(n, t) {
  var i = n + t,
      r = n - t,
      u = n * t,
      f = n / t,
      e = "Concat: " + n + t + "\nAdd: " + i + "\nSubtract: " + r + "\nMultiply: " + u + "\nDivide: " + f + "\n";alert(e);
}function looper() {
  for (var t = "", n = 1; n <= 10; n++) t += n + " ";alert(t);
}function fahrenheitToCelsius(n) {
  var t = (n - 32) * 5 / 9;alert(n + " degrees in Fahrenheit is " + t + " degrees Celcius");
}function celciusToFahrenheit() {
  var n = arguments[0] * 9 / 5 + 32;alert(arguments[0] + " degrees in Celcius is " + n + " degrees Fahrenheit");
}function sumOdd() {
  var t, n;if (myArray.length > 0 && typeof (myArray[0] != "undefined")) {
    for (t = 0, n = 0; n < myArray.length; n++) typeof myArray[n] == "number" && (myArray[n] - 1) % 2 == 0 && (t += myArray[n]);alert("Sum of odds is: " + t);
  } else {
    for (n = 0; n <= 10; n++) myArray[n] = n;alert("We had an empty array. Please run Sum the Odds again.");
  }
}var myArray = [];

